
package bank_management_system;

public class Bank_Management_System {

  public static void main(String[] args) {

    mainpage mr = new mainpage();
    mr.setVisible(true);

  }

}